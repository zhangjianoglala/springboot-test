package org.sang;

/**
 * Created by sang on 17-2-19.
 */
public class User3 {
    public void add() {
        System.out.println("add3()---------");
    }
}
