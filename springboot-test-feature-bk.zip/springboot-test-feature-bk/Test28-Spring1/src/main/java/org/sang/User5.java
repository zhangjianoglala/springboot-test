package org.sang;

/**
 * Created by sang on 17-2-20.
 */
public class User5 {
    private String username;

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "User5{" +
                "username='" + username + '\'' +
                '}';
    }
}
