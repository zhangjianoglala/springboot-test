package org.sang;

/**
 * Created by sang on 17-2-19.
 */
public class User3Factory {
    public User3 getUser3() {
        return new User3();
    }
}
