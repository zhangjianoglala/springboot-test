package org.sang;

/**
 * Created by sang on 17-2-20.
 */
public class UserDao {
    public void getData() {
        System.out.println("获取到数据啦!");
    }
}
