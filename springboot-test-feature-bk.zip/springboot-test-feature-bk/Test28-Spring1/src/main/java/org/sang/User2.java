package org.sang;

/**
 * Created by sang on 17-2-19.
 */
public class User2 {
    public void add() {
        System.out.println("add2()---------");
    }
}
