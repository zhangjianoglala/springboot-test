package org.sang;

/**
 * Created by sang on 17-2-20.
 */
public class User6 {
    private String username;

    public void setUsername(String username) {
        this.username = username;
    }
    public void test() {
        System.out.println(username);
    }
}
