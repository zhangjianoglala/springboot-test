package org.sang;

/**
 * Created by sang on 17-2-19.
 */
public class User2Factory {
    public static User2 getInstance() {
        return new User2();
    }
}
