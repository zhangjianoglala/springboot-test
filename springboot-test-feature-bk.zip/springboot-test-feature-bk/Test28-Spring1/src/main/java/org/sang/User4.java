package org.sang;

/**
 * Created by sang on 17-2-20.
 */
public class User4 {
    private String username;

    public User4(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "User4{" +
                "username='" + username + '\'' +
                '}';
    }
}
